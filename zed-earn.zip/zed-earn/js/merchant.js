// ===== ZED EARN - MERCHANT =====
// Placeholder for merchant mode
