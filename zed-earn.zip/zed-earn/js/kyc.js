// ===== ZED EARN - KYC =====

const Kyc = {
    previews: {},

    preview(input, type) {
        if (input.files && input.files[0]) {
            const reader = new FileReader();
            reader.onload = function(e) {
                const container = document.getElementById('kyc-' + type + '-preview');
                if (container) {
                    container.innerHTML = '<img src="' + e.target.result + '" class="kyc-preview">';
                }
                Kyc.previews[type] = e.target.result;
            };
            reader.readAsDataURL(input.files[0]);
        }
    },

    submit() {
        if (!this.previews.front || !this.previews.back || !this.previews.selfie) {
            App.showToast('يرجى رفع جميع الصور المطلوبة', 'error');
            return;
        }

        Storage.setKyc({
            status: 'pending',
            docs: this.previews,
            submittedAt: new Date().toISOString()
        });

        App.showToast('تم إرسال المستندات للمراجعة');
        App.goBack();
    }
};
