// ===== ZED EARN - LEADERBOARD =====
// Static demo data, no logic needed
