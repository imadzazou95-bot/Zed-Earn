// ===== ZED EARN - TASKS =====

const Tasks = {
    currentTask: null,

    showDetail(taskId) {
        const task = DEMO_TASKS.find(t => t.id === taskId);
        if (!task) return;
        this.currentTask = task;

        const app = document.getElementById('app');
        const existing = document.getElementById('screen-task-detail');
        if (existing) existing.remove();

        const div = document.createElement('div');
        div.innerHTML = Screens.taskDetail(task);
        app.appendChild(div.firstElementChild);

        App.goTo('task-detail');
    },

    acceptTask(taskId) {
        const task = DEMO_TASKS.find(t => t.id === taskId);
        if (!task) return;

        const myTasks = Storage.getMyTasks();
        if (myTasks.find(t => t.id === taskId)) {
            App.showToast('لقد قبلت هذه المهمة مسبقاً', 'error');
            return;
        }

        myTasks.push({
            id: task.id,
            title: task.title,
            commission: task.commission,
            status: 'accepted',
            acceptedAt: new Date().toISOString()
        });
        Storage.setMyTasks(myTasks);

        App.showToast('تم قبول المهمة!');
        this.showDetail(taskId);
    },

    previewProof(input) {
        if (input.files && input.files[0]) {
            const reader = new FileReader();
            reader.onload = function(e) {
                const preview = document.getElementById('proof-preview');
                if (preview) {
                    preview.innerHTML = '<img src="' + e.target.result + '" class="kyc-preview">';
                }
            };
            reader.readAsDataURL(input.files[0]);
        }
    },

    submitProof(taskId) {
        const myTasks = Storage.getMyTasks();
        const task = myTasks.find(t => t.id === taskId);
        if (task) {
            task.status = 'pending';
            task.submittedAt = new Date().toISOString();
            Storage.setMyTasks(myTasks);
        }

        App.showToast('تم إرسال الإثبات للمراجعة');
        this.showDetail(taskId);
    },

    cancelTask(taskId) {
        if (!confirm('هل أنت متأكد من إلغاء المهمة؟')) return;

        const myTasks = Storage.getMyTasks().filter(t => t.id !== taskId);
        Storage.setMyTasks(myTasks);
        App.showToast('تم إلغاء المهمة');
        App.goBack();
    }
};
