// ===== ZED EARN - LOCAL STORAGE =====

const Storage = {
    prefix: 'zedearn_',

    get(key) {
        try {
            const data = localStorage.getItem(this.prefix + key);
            return data ? JSON.parse(data) : null;
        } catch(e) { return null; }
    },

    set(key, value) {
        localStorage.setItem(this.prefix + key, JSON.stringify(value));
    },

    remove(key) {
        localStorage.removeItem(this.prefix + key);
    },

    clear() {
        Object.keys(localStorage)
            .filter(k => k.startsWith(this.prefix))
            .forEach(k => localStorage.removeItem(k));
    },

    // User
    getUser() { return this.get('user'); },
    setUser(user) { this.set('user', user); },

    // Theme
    getTheme() { return this.get('theme') || 'light'; },
    setTheme(theme) { this.set('theme', theme); },

    // Lang
    getLang() { return this.get('lang') || 'ar'; },
    setLang(lang) { this.set('lang', lang); },

    // Tasks
    getMyTasks() { return this.get('my_tasks') || []; },
    setMyTasks(tasks) { this.set('my_tasks', tasks); },

    // Wallet
    getTransactions() { return this.get('transactions') || []; },
    addTransaction(tx) {
        const txs = this.getTransactions();
        txs.unshift({ ...tx, id: Date.now(), date: new Date().toISOString() });
        this.set('transactions', txs);
    },

    // KYC
    getKyc() { return this.get('kyc') || { status: 'none', docs: {} }; },
    setKyc(kyc) { this.set('kyc', kyc); },

    // Notifications
    getNotifications() { return this.get('notifications') || []; },
    addNotification(notif) {
        const notifs = this.getNotifications();
        notifs.unshift({ ...notif, id: Date.now(), read: false });
        this.set('notifications', notifs);
    },
    markNotifRead(id) {
        const notifs = this.getNotifications();
        const n = notifs.find(x => x.id === id);
        if (n) n.read = true;
        this.set('notifications', notifs);
    },

    // Referral
    getReferral() { return this.get('referral') || { code: null, count: 0, earnings: 0 }; },
    setReferral(ref) { this.set('referral', ref); },

    // Chat
    getChatMessages() { return this.get('chat_messages') || DEMO_CHAT; },
    addChatMessage(msg) {
        const msgs = this.getChatMessages();
        msgs.push(msg);
        this.set('chat_messages', msgs);
    },

    // First visit
    isFirstVisit() { return !this.get('visited'); },
    setVisited() { this.set('visited', true); },
};
