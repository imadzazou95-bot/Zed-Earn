// ===== ZED EARN - AUTH =====

const Auth = {
    tempPhone: null,

    validatePhone(input) {
        input.value = input.value.replace(/[^0-9]/g, '');
        const error = document.getElementById('phone-error');
        const valid = /^0[5-7][0-9]{8}$/.test(input.value);
        if (error) error.classList.toggle('show', !valid && input.value.length >= 10);
        this.toggleRegBtn();
    },

    toggleRegBtn() {
        const phone = document.getElementById('reg-phone')?.value || '';
        const terms = document.getElementById('reg-terms')?.checked || false;
        const btn = document.getElementById('btn-register');
        if (btn) btn.disabled = !( /^0[5-7][0-9]{8}$/.test(phone) && terms );
    },

    register() {
        const phone = document.getElementById('reg-phone').value;
        const email = document.getElementById('reg-email').value;
        this.tempPhone = phone;

        // Generate random email if empty
        const finalEmail = email || `user_${Date.now()}@zedearn.com`;

        Storage.setUser({
            phone: phone,
            email: finalEmail,
            name: '',
            balance: 0,
            earnings: 0,
            avatar: null,
            createdAt: new Date().toISOString()
        });

        // Generate referral code
        const ref = Storage.getReferral();
        if (!ref.code) {
            ref.code = Profile.generateReferralCode();
            Storage.setReferral(ref);
        }

        this.showOtp(phone);
    },

    login() {
        const phone = document.getElementById('login-phone').value;
        if (!/^0[5-7][0-9]{8}$/.test(phone)) {
            App.showToast('رقم هاتف غير صحيح', 'error');
            return;
        }
        this.tempPhone = phone;
        this.showOtp(phone);
    },

    showOtp(phone) {
        App.goTo('otp');
        const display = document.getElementById('otp-phone-display');
        if (display) display.textContent = '+213 ' + phone;

        // Auto-fill demo OTP
        setTimeout(() => {
            const inputs = document.querySelectorAll('#otp-inputs input');
            inputs.forEach((input, i) => {
                input.value = (i + 1).toString();
            });
        }, 500);
    },

    handleOtpInput(input, index) {
        input.value = input.value.replace(/[^0-9]/g, '');
        if (input.value && index < 5) {
            const inputs = document.querySelectorAll('#otp-inputs input');
            inputs[index + 1].focus();
        }
    },

    handleOtpKey(input, index, event) {
        if (event.key === 'Backspace' && !input.value && index > 0) {
            const inputs = document.querySelectorAll('#otp-inputs input');
            inputs[index - 1].focus();
        }
    },

    verifyOtp() {
        const inputs = document.querySelectorAll('#otp-inputs input');
        const code = Array.from(inputs).map(i => i.value).join('');
        if (code.length !== 6) {
            App.showToast('أدخل الرمز كاملاً', 'error');
            return;
        }
        App.showToast('تم التحقق بنجاح!');
        App.goTo('scrollspy');
    },

    resendOtp() {
        App.showToast('تم إعادة إرسال الرمز');
    },

    logout() {
        if (confirm('هل أنت متأكد من تسجيل الخروج؟')) {
            Storage.clear();
            location.reload();
        }
    }
};
