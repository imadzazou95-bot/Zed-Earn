// ===== ZED EARN - REFERRAL =====

const Referral = {
    copy() {
        const code = document.getElementById('ref-code')?.textContent || '';
        navigator.clipboard.writeText(code).then(() => {
            App.showToast('تم نسخ الكود!');
        });
    },

    share() {
        const code = document.getElementById('ref-code')?.textContent || '';
        const text = 'انضم إلى Zed Earn واكسب معي! كود الإحالة: ' + code;

        if (navigator.share) {
            navigator.share({ title: 'Zed Earn', text: text });
        } else {
            navigator.clipboard.writeText(text);
            App.showToast('تم نسخ رسالة المشاركة!');
        }
    }
};
