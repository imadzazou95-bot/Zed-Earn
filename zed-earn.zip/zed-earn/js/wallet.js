// ===== ZED EARN - WALLET =====

const Wallet = {
    showDeposit() {
        App.showToast('قريباً: إضافة رصيد', 'info');
    },

    withdraw(method) {
        const user = Storage.getUser() || {};
        const balance = user.balance || 0;

        if (balance < 1000) {
            App.showToast('الحد الأدنى للسحب 1,000 DZD', 'error');
            return;
        }

        const kyc = Storage.getKyc();
        if (kyc.status !== 'verified') {
            App.showToast('يجب إكمال التحقق من الهوية أولاً', 'error');
            App.goTo('kyc');
            return;
        }

        // Simulate withdrawal
        const amount = balance;
        user.balance = 0;
        Storage.setUser(user);

        Storage.addTransaction({
            type: 'withdrawal',
            amount: amount,
            method: method,
            title: 'سحب ' + (method === 'ccp' ? 'CCP' : method === 'wallet' ? 'محفظة' : 'بطاقة')
        });

        App.showToast('تم إرسال طلب السحب بنجاح!');
        App.switchTab('withdraw');
    }
};
