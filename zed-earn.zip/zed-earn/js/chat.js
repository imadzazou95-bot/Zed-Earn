// ===== ZED EARN - CHAT =====

const Chat = {
    send() {
        const input = document.getElementById('chat-input');
        const text = input?.value?.trim();
        if (!text) return;

        const now = new Date();
        const time = now.getHours() + ':' + String(now.getMinutes()).padStart(2, '0');

        const msg = { from: 'user', text: text, time: time };
        Storage.addChatMessage(msg);

        // Add to UI
        const container = document.getElementById('chat-messages');
        if (container) {
            const bubble = document.createElement('div');
            bubble.className = 'chat-bubble user';
            bubble.innerHTML = text + '<div class="text-xs opacity-60 mt-1 text-right">' + time + '</div>';
            container.appendChild(bubble);
            container.scrollTop = container.scrollHeight;
        }

        input.value = '';

        // Auto-reply
        setTimeout(() => {
            const reply = { 
                from: 'support', 
                text: 'شكراً لتواصلك معنا! فريق الدعم سيقوم بالرد عليك في أقرب وقت.', 
                time: time 
            };
            Storage.addChatMessage(reply);

            if (container) {
                const bubble = document.createElement('div');
                bubble.className = 'chat-bubble support';
                bubble.innerHTML = reply.text + '<div class="text-xs opacity-60 mt-1 text-right">' + time + '</div>';
                container.appendChild(bubble);
                container.scrollTop = container.scrollHeight;
            }
        }, 1500);
    }
};
