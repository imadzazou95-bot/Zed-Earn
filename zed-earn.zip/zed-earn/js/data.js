// ===== ZED EARN - DATA & TRANSLATIONS =====

const I18N = {
    ar: {
        // Nav
        nav_home: "الرئيسية", nav_tasks: "المهام", nav_withdraw: "السحب", nav_profile: "الحساب",
        // Auth
        login_title: "تسجيل الدخول", login_subtitle: "أدخل رقم هاتفك للمتابعة",
        register_title: "إنشاء حساب", register_subtitle: "أدخل بياناتك للتسجيل",
        phone_label: "رقم الهاتف الجزائري 🇩🇿", phone_placeholder: "05XX XX XX XX",
        email_label: "البريد الإلكتروني (اختياري)", email_placeholder: "example@email.com",
        terms_text: "أوافق على شروط الاستخدام وسياسة الخصوصية",
        btn_login: "تسجيل الدخول", btn_register: "إنشاء الحساب",
        have_account: "لديك حساب؟ تسجيل الدخول", no_account: "ليس لديك حساب؟ سجّل",
        // Onboarding
        onb1_title: "اعمل من هاتفك", onb1_desc: "كل ما تحتاجه هو هاتفك والإنترنت. ابدأ بسهولة من أي مكان وفي أي وقت.",
        onb2_title: "عمولات بالدينار الجزائري", onb2_desc: "احصل على عمولاتك مباشرة بالدينار الجزائري. سحب فوري عبر CCP أو المحافظ الإلكترونية.",
        onb3_title: "ابدأ رحلتك الآن", onb3_desc: "سجّل حسابك في أقل من دقيقة وكن من أوائل المستخدمين على المنصة.",
        btn_next: "التالي", btn_start: "ابدأ الآن",
        // Home
        welcome: "مرحباً 👋", balance_label: "الرصيد المتاح",
        btn_deposit: "إيداع", btn_withdraw: "سحب",
        tasks_label: "مهام", completed_label: "مكتملة", earnings_label: "عمولات",
        available_tasks: "مهام متاحة", view_all: "عرض الكل",
        // Tasks
        tasks_title: "المهام", tasks_subtitle: "اختر مهمة وابدأ بالعمل",
        task_accept: "قبول المهمة", task_locked: "مغلق",
        // Task Detail
        task_detail_title: "تفاصيل المهمة", task_requirements: "المتطلبات",
        task_steps: "خطوات التنفيذ", task_proof: "رفع إثبات الإنجاز",
        btn_submit_proof: "إرسال الإثبات", btn_cancel_task: "إلغاء المهمة",
        // Withdraw
        withdraw_title: "السحب", withdraw_subtitle: "سحب أرباحك بسهولة",
        withdrawable: "الرصيد القابل للسحب", min_withdraw: "الحد الأدنى للسحب: 1,000 DZD",
        withdraw_methods: "طرق السحب", withdraw_history: "سجل السحب",
        method_ccp: "CCP - بريد الجزائر", method_wallet: "محفظة إلكترونية", method_card: "بطاقة بنكية",
        // Profile
        profile_title: "الملف الشخصي", edit_profile: "تعديل الملف الشخصي",
        payment_methods: "طرق الدفع", terms: "الشروط والأحكام",
        help: "المساعدة والدعم", logout: "تسجيل الخروج",
        // KYC
        kyc_title: "التحقق من الهوية", kyc_subtitle: "أكمل التحقق لتتمكن من السحب",
        kyc_pending: "⏳ قيد المراجعة", kyc_verified: "✅ تم التحقق",
        kyc_id_front: "صورة بطاقة التعريف (الوجه)", kyc_id_back: "صورة بطاقة التعريف (الظهر)",
        kyc_selfie: "سيلفي مع البطاقة", btn_submit_kyc: "إرسال للتحقق",
        // Referral
        referral_title: "الإحالات", referral_subtitle: "ادعو أصدقاءك واكسب معاً",
        your_code: "كود الإحالة الخاص بك", copy: "نسخ", share: "مشاركة",
        referrals_count: "عدد الإحالات", referral_earnings: "أرباح الإحالات", total_earned: "إجمالي الأرباح",
        // Leaderboard
        leaderboard_title: "المتصدرين", leaderboard_subtitle: "أفضل المسوقين هذا الشهر",
        // Notifications
        notif_title: "الإشعارات", notif_empty: "لا توجد إشعارات جديدة",
        // Chat
        chat_title: "الدعم الفني", chat_placeholder: "اكتب رسالتك هنا...",
        // Merchant
        merchant_title: "وضع التاجر", merchant_subtitle: "أضف منتجاتك واطلب مهام تسويقية",
        merchant_products: "منتجاتي", merchant_add_product: "إضافة منتج جديد",
        // Wallet
        wallet_title: "المحفظة", wallet_history: "سجل المعاملات",
        tx_income: "إيراد", tx_outcome: "سحب", tx_pending: "قيد المراجعة",
        // OTP
        otp_title: "تأكيد رقم الهاتف", otp_subtitle: "أدخل الرمز المُرسل إلى",
        btn_verify: "تحقق", btn_resend: "إعادة الإرسال",
        // Misc
        soon: "قريباً", save: "حفظ", skip: "تخطي", cancel: "إلغاء",
        success: "تم بنجاح!", error: "حدث خطأ", loading: "جاري التحميل...",
        currency: "DZD", level_beginner: "مبتدئ", level_active: "نشط", level_pro: "محترف", level_vip: "VIP",
    },
    fr: {
        nav_home: "Accueil", nav_tasks: "Tâches", nav_withdraw: "Retrait", nav_profile: "Profil",
        login_title: "Connexion", login_subtitle: "Entrez votre numéro de téléphone",
        register_title: "Inscription", register_subtitle: "Entrez vos informations",
        phone_label: "Téléphone Algérien 🇩🇿", phone_placeholder: "05XX XX XX XX",
        email_label: "Email (optionnel)", email_placeholder: "exemple@email.com",
        terms_text: "J'accepte les conditions d'utilisation",
        btn_login: "Connexion", btn_register: "Créer un compte",
        have_account: "Déjà un compte? Connectez-vous", no_account: "Pas de compte? Inscrivez-vous",
        onb1_title: "Travaillez depuis votre téléphone", onb1_desc: "Tout ce dont vous avez besoin est votre téléphone et Internet.",
        onb2_title: "Commissions en Dinars", onb2_desc: "Recevez vos commissions directement en Dinars Algériens.",
        onb3_title: "Commencez maintenant", onb3_desc: "Inscrivez-vous en moins d'une minute.",
        btn_next: "Suivant", btn_start: "Commencer",
        welcome: "Bonjour 👋", balance_label: "Solde disponible",
        btn_deposit: "Dépôt", btn_withdraw: "Retrait",
        tasks_label: "Tâches", completed_label: "Terminées", earnings_label: "Gains",
        available_tasks: "Tâches disponibles", view_all: "Voir tout",
        tasks_title: "Tâches", tasks_subtitle: "Choisissez une tâche et commencez",
        task_accept: "Accepter", task_locked: "Verrouillé",
        task_detail_title: "Détails", task_requirements: "Exigences",
        task_steps: "Étapes", task_proof: "Preuve de réalisation",
        btn_submit_proof: "Envoyer", btn_cancel_task: "Annuler",
        withdraw_title: "Retrait", withdraw_subtitle: "Retirez vos gains facilement",
        withdrawable: "Solde retirable", min_withdraw: "Minimum: 1,000 DZD",
        withdraw_methods: "Méthodes", withdraw_history: "Historique",
        method_ccp: "CCP - Algérie Poste", method_wallet: "Portefeuille", method_card: "Carte bancaire",
        profile_title: "Profil", edit_profile: "Modifier", payment_methods: "Paiements",
        terms: "Conditions", help: "Aide", logout: "Déconnexion",
        kyc_title: "Vérification", kyc_subtitle: "Complétez pour retirer",
        kyc_pending: "⏳ En cours", kyc_verified: "✅ Vérifié",
        kyc_id_front: "Carte ID (recto)", kyc_id_back: "Carte ID (verso)", kyc_selfie: "Selfie avec carte",
        referral_title: "Parrainage", referral_subtitle: "Invitez vos amis",
        your_code: "Votre code", copy: "Copier", share: "Partager",
        referrals_count: "Parrainages", referral_earnings: "Gains", total_earned: "Total",
        leaderboard_title: "Classement", leaderboard_subtitle: "Top marketers ce mois",
        notif_title: "Notifications", notif_empty: "Aucune notification",
        chat_title: "Support", chat_placeholder: "Écrivez votre message...",
        merchant_title: "Mode Marchand", merchant_subtitle: "Ajoutez vos produits",
        wallet_title: "Portefeuille", wallet_history: "Historique",
        tx_income: "Revenu", tx_outcome: "Retrait", tx_pending: "En cours",
        otp_title: "Vérification", otp_subtitle: "Entrez le code envoyé à",
        btn_verify: "Vérifier", btn_resend: "Renvoyer",
        soon: "Bientôt", save: "Enregistrer", skip: "Passer", cancel: "Annuler",
        success: "Succès!", error: "Erreur", loading: "Chargement...",
        currency: "DZD", level_beginner: "Débutant", level_active: "Actif", level_pro: "Pro", level_vip: "VIP",
    },
    en: {
        nav_home: "Home", nav_tasks: "Tasks", nav_withdraw: "Withdraw", nav_profile: "Profile",
        login_title: "Log In", login_subtitle: "Enter your phone number",
        register_title: "Register", register_subtitle: "Enter your details",
        phone_label: "Algerian Phone 🇩🇿", phone_placeholder: "05XX XX XX XX",
        email_label: "Email (optional)", email_placeholder: "example@email.com",
        terms_text: "I agree to Terms & Privacy Policy",
        btn_login: "Log In", btn_register: "Create Account",
        have_account: "Have an account? Log In", no_account: "No account? Register",
        onb1_title: "Work From Your Phone", onb1_desc: "All you need is your phone and internet. Start easily from anywhere.",
        onb2_title: "Commissions in Dinars", onb2_desc: "Get your commissions directly in Algerian Dinars. Instant withdrawal via CCP or e-wallets.",
        onb3_title: "Start Your Journey", onb3_desc: "Register in less than a minute and be among the first users.",
        btn_next: "Next", btn_start: "Get Started",
        welcome: "Welcome 👋", balance_label: "Available Balance",
        btn_deposit: "Deposit", btn_withdraw: "Withdraw",
        tasks_label: "Tasks", completed_label: "Completed", earnings_label: "Earnings",
        available_tasks: "Available Tasks", view_all: "View All",
        tasks_title: "Tasks", tasks_subtitle: "Choose a task and start working",
        task_accept: "Accept Task", task_locked: "Locked",
        task_detail_title: "Task Details", task_requirements: "Requirements",
        task_steps: "Steps", task_proof: "Upload Proof",
        btn_submit_proof: "Submit Proof", btn_cancel_task: "Cancel Task",
        withdraw_title: "Withdraw", withdraw_subtitle: "Withdraw your earnings easily",
        withdrawable: "Withdrawable Balance", min_withdraw: "Minimum: 1,000 DZD",
        withdraw_methods: "Methods", withdraw_history: "History",
        method_ccp: "CCP - Algeria Post", method_wallet: "E-Wallet", method_card: "Bank Card",
        profile_title: "Profile", edit_profile: "Edit Profile", payment_methods: "Payment Methods",
        terms: "Terms", help: "Help & Support", logout: "Log Out",
        kyc_title: "Identity Verification", kyc_subtitle: "Complete to enable withdrawals",
        kyc_pending: "⏳ Pending", kyc_verified: "✅ Verified",
        kyc_id_front: "ID Card (Front)", kyc_id_back: "ID Card (Back)", kyc_selfie: "Selfie with ID",
        referral_title: "Referrals", referral_subtitle: "Invite friends & earn together",
        your_code: "Your Code", copy: "Copy", share: "Share",
        referrals_count: "Referrals", referral_earnings: "Earnings", total_earned: "Total Earned",
        leaderboard_title: "Leaderboard", leaderboard_subtitle: "Top marketers this month",
        notif_title: "Notifications", notif_empty: "No new notifications",
        chat_title: "Support", chat_placeholder: "Type your message...",
        merchant_title: "Merchant Mode", merchant_subtitle: "Add your products & request marketing tasks",
        wallet_title: "Wallet", wallet_history: "Transaction History",
        tx_income: "Income", tx_outcome: "Withdrawal", tx_pending: "Pending",
        otp_title: "Verify Phone", otp_subtitle: "Enter code sent to",
        btn_verify: "Verify", btn_resend: "Resend",
        soon: "Soon", save: "Save", skip: "Skip", cancel: "Cancel",
        success: "Success!", error: "Error", loading: "Loading...",
        currency: "DZD", level_beginner: "Beginner", level_active: "Active", level_pro: "Pro", level_vip: "VIP",
    }
};

// Demo Tasks Data
const DEMO_TASKS = [
    {
        id: 1, title: "مشاركة منتج على فيسبوك", title_fr: "Partager un produit sur Facebook", title_en: "Share product on Facebook",
        desc: "شارك رابط المنتج على صفحتك الشخصية مع وصف قصير",
        desc_fr: "Partagez le lien du produit sur votre page avec une courte description",
        desc_en: "Share the product link on your page with a short description",
        commission: 150, type: "easy", icon: "📱",
        requirements: ["حساب فيسبوك نشط", "500 صديق على الأقل"],
        steps: ["انسخ رابط المنتج", "انشره على فيسبوك", "أرفق وصفاً جذاباً"]
    },
    {
        id: 2, title: "كتابة مراجعة لمنتج", title_fr: "Écrire un avis", title_en: "Write a product review",
        desc: "اكتب مراجعة صادقة للمنتج بطول 100 كلمة على الأقل",
        desc_fr: "Écrivez un avis honnête d'au moins 100 mots",
        desc_en: "Write an honest review of at least 100 words",
        commission: 300, type: "medium", icon: "⭐",
        requirements: ["إتقان اللغة العربية أو الفرنسية", "خبرة في كتابة المراجعات"],
        steps: ["جرب المنتج", "اكتب مراجعتك", "أرفق صوراً"]
    },
    {
        id: 3, title: "تصوير فيديو للمنتج", title_fr: "Filmer une vidéo", title_en: "Record product video",
        desc: "صور فيديو مدته دقيقة واحدة يعرض مميزات المنتج",
        desc_fr: "Filmez une vidéo d'une minute montrant les fonctionnalités",
        desc_en: "Record a one-minute video showing product features",
        commission: 500, type: "hard", icon: "🎥",
        requirements: ["كاميرا هاتف جيدة", "إضاءة مناسبة"],
        steps: ["اقرأ دليل المنتج", "صور فيديو واضح", "ارفع الفيديو"]
    },
    {
        id: 4, title: "حملة تسويقية متكاملة", title_fr: "Campagne marketing", title_en: "Full marketing campaign",
        desc: "نفذ حملة تسويقية متكاملة على وسائل التواصل",
        desc_fr: "Exécutez une campagne marketing complète",
        desc_en: "Execute a complete marketing campaign",
        commission: 1000, type: "vip", icon: "🚀",
        requirements: ["مستوى VIP", "إكمال 10 مهام سابقة"],
        steps: ["خطط للحملة", "نفذ على جميع المنصات", "قدم تقريراً"],
        locked: true
    }
];

// Demo Leaderboard
const DEMO_LEADERBOARD = [
    { name: "أحمد بن علي", earnings: 45000, tasks: 120, avatar: "👨" },
    { name: "سارة موسى", earnings: 38200, tasks: 98, avatar: "👩" },
    { name: "يوسف كمال", earnings: 31500, tasks: 85, avatar: "🧑" },
    { name: "ليلى عمر", earnings: 28900, tasks: 76, avatar: "👩‍🦱" },
    { name: "كريم فؤاد", earnings: 24100, tasks: 64, avatar: "👨‍🦱" },
    { name: "نور الدين", earnings: 19800, tasks: 52, avatar: "🧔" },
    { name: "فاطمة الزهراء", earnings: 16500, tasks: 45, avatar: "👩‍🦰" },
    { name: "عمر خالد", earnings: 14200, tasks: 38, avatar: "👦" },
    { name: "هدى سعيد", earnings: 11800, tasks: 31, avatar: "👧" },
    { name: "إبراهيم", earnings: 9500, tasks: 25, avatar: "👨‍🦳" },
];

// Demo Notifications
const DEMO_NOTIFICATIONS = [
    { id: 1, title: "تم قبول مهمتك", body: "مهمة #123 - مشاركة منتج على فيسبوك", type: "success", time: "منذ 5 دقائق", read: false },
    { id: 2, title: "إيداع جديد", body: "تم إيداع 150 DZD في محفظتك", type: "success", time: "منذ ساعة", read: false },
    { id: 3, title: "مهمة جديدة متاحة", body: "تصوير فيديو - عمولة 500 DZD", type: "info", time: "منذ 3 ساعات", read: true },
    { id: 4, title: "تذكير", body: "أكمل ملفك الشخصي للحصول على مكافأة", type: "warning", time: "أمس", read: true },
];

// Demo Chat Messages
const DEMO_CHAT = [
    { from: "support", text: "مرحباً! كيف يمكنني مساعدتك اليوم؟", time: "10:00" },
    { from: "user", text: "مرحباً، كيف يمكنني سحب أرباحي؟", time: "10:02" },
    { from: "support", text: "يمكنك السحب عبر CCP أو المحافظ الإلكترونية بمجرد وصول رصيدك إلى 1,000 DZD. هل تحتاج مساعدة في إضافة طريقة سحب؟", time: "10:03" },
];

// Levels Config
const LEVELS = [
    { name: "beginner", minTasks: 0, commissionBonus: 0, color: "#3b82f6" },
    { name: "active", minTasks: 10, commissionBonus: 0.05, color: "#10b981" },
    { name: "pro", minTasks: 50, commissionBonus: 0.10, color: "#f59e0b" },
    { name: "vip", minTasks: 100, commissionBonus: 0.20, color: "#8b5cf6" },
];

function t(key) {
    const lang = window.APP_LANG || 'ar';
    return I18N[lang]?.[key] || I18N['ar'][key] || key;
}
