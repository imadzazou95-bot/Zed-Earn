// ===== ZED EARN - NOTIFICATIONS =====

const Notifications = {
    markRead(id) {
        Storage.markNotifRead(id);
        const el = document.querySelector('.notif-item.unread');
        if (el) el.classList.remove('unread');
    }
};
