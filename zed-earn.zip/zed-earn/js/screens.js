// ===== ZED EARN - SCREEN TEMPLATES =====

const Screens = {
    // Splash
    splash() {
        return `
        <div id="screen-splash" class="screen splash-screen active">
            <div class="splash-logo">⚡</div>
            <h1 class="splash-title">Zed Earn</h1>
            <p class="splash-subtitle">اكسب من أي مكان</p>
            <div class="splash-dots">
                <span></span><span></span><span></span>
            </div>
        </div>`;
    },

    // Onboarding
    onboarding() {
        return `
        <div id="screen-onboarding" class="screen">
            <div class="onboarding-header">
                <div class="steps-indicator">
                    <div class="step-circle active" id="ob-step-1">1</div>
                    <div class="step-line pending" id="ob-line-1"></div>
                    <div class="step-circle pending" id="ob-step-2">2</div>
                    <div class="step-line pending" id="ob-line-2"></div>
                    <div class="step-circle pending" id="ob-step-3">3</div>
                </div>
            </div>
            <div class="onboarding-slide active" id="ob-slide-1">
                <div class="flex-1 flex flex-col items-center justify-center">
                    <div class="onb-illustration blue">📱</div>
                    <h2 class="onb-title">${t('onb1_title')}</h2>
                    <p class="onb-desc">${t('onb1_desc')}</p>
                </div>
                <button class="btn btn-primary" onclick="App.nextOnboarding(2)">${t('btn_next')}</button>
            </div>
            <div class="onboarding-slide" id="ob-slide-2">
                <div class="flex-1 flex flex-col items-center justify-center">
                    <div class="onb-illustration amber">💰</div>
                    <h2 class="onb-title">${t('onb2_title')}</h2>
                    <p class="onb-desc">${t('onb2_desc')}</p>
                </div>
                <button class="btn btn-primary" onclick="App.nextOnboarding(3)">${t('btn_next')}</button>
            </div>
            <div class="onboarding-slide" id="ob-slide-3">
                <div class="flex-1 flex flex-col items-center justify-center">
                    <div class="onb-illustration green">🚀</div>
                    <h2 class="onb-title">${t('onb3_title')}</h2>
                    <p class="onb-desc">${t('onb3_desc')}</p>
                </div>
                <button class="btn btn-primary" onclick="App.goTo('register')">${t('btn_start')}</button>
            </div>
        </div>`;
    },

    // Register
    register() {
        return `
        <div id="screen-register" class="screen">
            <div class="px-5 pt-12 pb-8 flex-1 flex flex-col">
                <div class="text-center mb-10">
                    <div class="w-16 h-16 bg-gradient-to-br from-amber-400 to-amber-600 rounded-2xl flex items-center justify-center mx-auto mb-4 text-3xl shadow-lg">👤</div>
                    <h2 class="text-2xl font-black">${t('register_title')}</h2>
                    <p class="text-sm text-[var(--text-muted)] mt-2">${t('register_subtitle')}</p>
                </div>
                <div class="space-y-5 flex-1">
                    <div class="input-group">
                        <label class="input-label">${t('phone_label')}</label>
                        <div class="flex gap-2">
                            <div class="input-prefix">
                                <span>🇩🇿</span><span>+213</span>
                            </div>
                            <input type="tel" id="reg-phone" class="input-field flex-1" placeholder="${t('phone_placeholder')}" maxlength="10" oninput="Auth.validatePhone(this)">
                        </div>
                        <p class="input-error" id="phone-error">يرجى إدخال رقم هاتف جزائري صحيح</p>
                    </div>
                    <div class="input-group">
                        <label class="input-label">${t('email_label')}</label>
                        <input type="email" id="reg-email" class="input-field" placeholder="${t('email_placeholder')}">
                    </div>
                    <label class="flex items-start gap-3 mt-4 cursor-pointer">
                        <input type="checkbox" id="reg-terms" class="w-5 h-5 mt-0.5 accent-amber-500" onchange="Auth.toggleRegBtn()">
                        <span class="text-xs text-[var(--text-muted)] leading-relaxed">${t('terms_text')}</span>
                    </label>
                </div>
                <div class="mt-6 space-y-3">
                    <button id="btn-register" class="btn btn-primary" onclick="Auth.register()" disabled>${t('btn_register')}</button>
                    <button class="btn btn-ghost" onclick="App.goTo('login')">${t('have_account')}</button>
                </div>
            </div>
        </div>`;
    },

    // Login
    login() {
        return `
        <div id="screen-login" class="screen">
            <div class="px-5 pt-12 pb-8 flex-1 flex flex-col">
                <div class="text-center mb-10">
                    <div class="w-16 h-16 bg-gradient-to-br from-blue-400 to-blue-600 rounded-2xl flex items-center justify-center mx-auto mb-4 text-3xl shadow-lg">🔐</div>
                    <h2 class="text-2xl font-black">${t('login_title')}</h2>
                    <p class="text-sm text-[var(--text-muted)] mt-2">${t('login_subtitle')}</p>
                </div>
                <div class="space-y-5 flex-1">
                    <div class="input-group">
                        <label class="input-label">${t('phone_label')}</label>
                        <div class="flex gap-2">
                            <div class="input-prefix">
                                <span>🇩🇿</span><span>+213</span>
                            </div>
                            <input type="tel" id="login-phone" class="input-field flex-1" placeholder="${t('phone_placeholder')}" maxlength="10">
                        </div>
                    </div>
                </div>
                <div class="mt-6 space-y-3">
                    <button class="btn btn-primary" onclick="Auth.login()">${t('btn_login')}</button>
                    <button class="btn btn-ghost" onclick="App.goTo('register')">${t('no_account')}</button>
                </div>
            </div>
        </div>`;
    },

    // OTP
    otp() {
        return `
        <div id="screen-otp" class="screen">
            <div class="px-5 pt-12 pb-8 flex-1 flex flex-col">
                <div class="text-center mb-8">
                    <div class="w-16 h-16 bg-gradient-to-br from-green-400 to-green-600 rounded-2xl flex items-center justify-center mx-auto mb-4 text-3xl shadow-lg">📱</div>
                    <h2 class="text-2xl font-black">${t('otp_title')}</h2>
                    <p class="text-sm text-[var(--text-muted)] mt-2">${t('otp_subtitle')} <span id="otp-phone-display" class="font-bold text-[var(--text)]"></span></p>
                </div>
                <div class="flex-1">
                    <div class="otp-inputs" id="otp-inputs">
                        <input type="text" maxlength="1" oninput="Auth.handleOtpInput(this,0)" onkeydown="Auth.handleOtpKey(this,0,event)">
                        <input type="text" maxlength="1" oninput="Auth.handleOtpInput(this,1)" onkeydown="Auth.handleOtpKey(this,1,event)">
                        <input type="text" maxlength="1" oninput="Auth.handleOtpInput(this,2)" onkeydown="Auth.handleOtpKey(this,2,event)">
                        <input type="text" maxlength="1" oninput="Auth.handleOtpInput(this,3)" onkeydown="Auth.handleOtpKey(this,3,event)">
                        <input type="text" maxlength="1" oninput="Auth.handleOtpInput(this,4)" onkeydown="Auth.handleOtpKey(this,4,event)">
                        <input type="text" maxlength="1" oninput="Auth.handleOtpInput(this,5)" onkeydown="Auth.handleOtpKey(this,5,event)">
                    </div>
                    <p class="text-center text-sm text-[var(--text-muted)] mt-4">
                        لم تستلم الرمز؟ <button class="text-amber-600 font-bold" onclick="Auth.resendOtp()">${t('btn_resend')}</button>
                    </p>
                </div>
                <button class="btn btn-primary mt-4" onclick="Auth.verifyOtp()">${t('btn_verify')}</button>
            </div>
        </div>`;
    },

    // Scrollspy Guide
    scrollspy() {
        return `
        <div id="screen-scrollspy" class="screen">
            <div class="page-header">
                <div>
                    <h1>📚 دليل المستخدم</h1>
                </div>
                <button class="btn-icon" onclick="App.toggleTheme()">🌙</button>
            </div>
            <div class="scrollspy-nav hide-scrollbar">
                <div class="scrollspy-nav-inner">
                    <button class="scrollspy-link active" onclick="App.scrollToSection('sec-intro',this)">المقدمة</button>
                    <button class="scrollspy-link" onclick="App.scrollToSection('sec-tasks',this)">المهام</button>
                    <button class="scrollspy-link" onclick="App.scrollToSection('sec-comm',this)">العمولات</button>
                    <button class="scrollspy-link" onclick="App.scrollToSection('sec-withdraw',this)">السحب</button>
                    <button class="scrollspy-link" onclick="App.scrollToSection('sec-rules',this)">القواعد</button>
                </div>
            </div>
            <div class="flex-1 overflow-y-auto pb-6" id="scrollspy-content">
                <div id="sec-intro" class="scrollspy-section">
                    <div class="card mb-4">
                        <div class="text-3xl mb-3">🎯</div>
                        <h3 class="text-lg font-bold mb-2">ما هو Zed Earn؟</h3>
                        <p class="text-sm text-[var(--text-muted)] leading-relaxed">Zed Earn هي منصة تسويق بالعمولة تربط بين العلامات التجارية والمسوقين في الجزائر. من خلال إكمال مهام بسيطة، يمكنك كسب عمولات حقيقية بالدينار الجزائري.</p>
                    </div>
                    <div class="card">
                        <div class="text-3xl mb-3">✅</div>
                        <h3 class="text-lg font-bold mb-2">لماذا نحن مختلفون؟</h3>
                        <ul class="space-y-2 text-sm text-[var(--text-muted)]">
                            <li class="flex items-start gap-2"><span class="text-green-500">✓</span> الدفع بالدينار الجزائري مباشرة</li>
                            <li class="flex items-start gap-2"><span class="text-green-500">✓</span> لا يوجد حد أدنى للسحب</li>
                            <li class="flex items-start gap-2"><span class="text-green-500">✓</span> مهام متنوعة تناسب جميع المستويات</li>
                            <li class="flex items-start gap-2"><span class="text-green-500">✓</span> دعم فني على مدار الساعة</li>
                        </ul>
                    </div>
                </div>
                <div id="sec-tasks" class="scrollspy-section">
                    <div class="card">
                        <div class="text-3xl mb-3">📋</div>
                        <h3 class="text-lg font-bold mb-3">أنواع المهام</h3>
                        <div class="space-y-3">
                            <div class="flex gap-3 p-3 bg-[var(--light)] rounded-xl">
                                <div class="w-10 h-10 bg-blue-500 rounded-lg flex items-center justify-center text-white font-bold shrink-0">1</div>
                                <div>
                                    <div class="font-bold text-sm">المهام الأساسية</div>
                                    <div class="text-xs text-[var(--text-muted)]">مشاركة منتجات — عمولة 5% إلى 15%</div>
                                </div>
                            </div>
                            <div class="flex gap-3 p-3 bg-[var(--light)] rounded-xl">
                                <div class="w-10 h-10 bg-amber-500 rounded-lg flex items-center justify-center text-white font-bold shrink-0">2</div>
                                <div>
                                    <div class="font-bold text-sm">المهام المتوسطة</div>
                                    <div class="text-xs text-[var(--text-muted)]">مراجعات — عمولة 15% إلى 25%</div>
                                </div>
                            </div>
                            <div class="flex gap-3 p-3 bg-[var(--light)] rounded-xl">
                                <div class="w-10 h-10 bg-purple-500 rounded-lg flex items-center justify-center text-white font-bold shrink-0">3</div>
                                <div>
                                    <div class="font-bold text-sm">المهام المميزة (VIP)</div>
                                    <div class="text-xs text-[var(--text-muted)]">حملات متكاملة — عمولة 30% إلى 50%</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="sec-comm" class="scrollspy-section">
                    <div class="card">
                        <div class="text-3xl mb-3">💵</div>
                        <h3 class="text-lg font-bold mb-3">نظام العمولات</h3>
                        <div class="grid grid-cols-3 gap-2">
                            <div class="text-center p-3 bg-blue-50 dark:bg-blue-900/20 rounded-xl">
                                <div class="text-lg font-black text-blue-600">5-15%</div>
                                <div class="text-xs text-[var(--text-muted)]">أساسي</div>
                            </div>
                            <div class="text-center p-3 bg-amber-50 dark:bg-amber-900/20 rounded-xl">
                                <div class="text-lg font-black text-amber-600">15-25%</div>
                                <div class="text-xs text-[var(--text-muted)]">متوسط</div>
                            </div>
                            <div class="text-center p-3 bg-purple-50 dark:bg-purple-900/20 rounded-xl">
                                <div class="text-lg font-black text-purple-600">30-50%</div>
                                <div class="text-xs text-[var(--text-muted)]">VIP</div>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="sec-withdraw" class="scrollspy-section">
                    <div class="card">
                        <div class="text-3xl mb-3">🏦</div>
                        <h3 class="text-lg font-bold mb-3">طرق السحب</h3>
                        <div class="space-y-3">
                            <div class="flex items-center gap-3 p-3 bg-[var(--light)] rounded-xl">
                                <span class="text-2xl">🏧</span>
                                <div><div class="font-bold text-sm">CCP - بريد الجزائر</div><div class="text-xs text-[var(--text-muted)]">تحويل مباشر خلال 24 ساعة</div></div>
                            </div>
                            <div class="flex items-center gap-3 p-3 bg-[var(--light)] rounded-xl">
                                <span class="text-2xl">📲</span>
                                <div><div class="font-bold text-sm">محافظ إلكترونية</div><div class="text-xs text-[var(--text-muted)]">D17, Mobimoney, BaridiMob</div></div>
                            </div>
                            <div class="flex items-center gap-3 p-3 bg-[var(--light)] rounded-xl">
                                <span class="text-2xl">💳</span>
                                <div><div class="font-bold text-sm">بطاقة بنكية</div><div class="text-xs text-[var(--text-muted)]">التحويل إلى حسابك البنكي</div></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="sec-rules" class="scrollspy-section">
                    <div class="card">
                        <div class="text-3xl mb-3">📜</div>
                        <h3 class="text-lg font-bold mb-2">القواعد والشروط</h3>
                        <ul class="space-y-2 text-sm text-[var(--text-muted)]">
                            <li class="flex items-start gap-2"><span class="text-amber-500">•</span> يجب أن يكون عمرك 18 عاماً على الأقل</li>
                            <li class="flex items-start gap-2"><span class="text-amber-500">•</span> رقم الهاتف يجب أن يكون جزائري وفعال</li>
                            <li class="flex items-start gap-2"><span class="text-amber-500">•</span> يمنع إنشاء حسابات متعددة</li>
                            <li class="flex items-start gap-2"><span class="text-amber-500">•</span> يجب إكمال المهمة بجودة عالية</li>
                            <li class="flex items-start gap-2"><span class="text-amber-500">•</span> يحق للمنصة تعليق أي حساب مخالف</li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="px-5 pb-6">
                <button class="btn btn-primary" onclick="App.goTo('profile-setup')">✓ لقد قرأت وفهمت</button>
            </div>
        </div>`;
    },

    // Profile Setup
    profileSetup() {
        return `
        <div id="screen-profile-setup" class="screen">
            <div class="px-5 pt-12 pb-8 flex-1 flex flex-col">
                <div class="text-center mb-8">
                    <h2 class="text-2xl font-black">إكمال الملف الشخصي</h2>
                    <p class="text-sm text-[var(--text-muted)] mt-2">أضف صورتك ومعلوماتك</p>
                </div>
                <div class="flex flex-col items-center mb-8">
                    <div class="avatar-upload" onclick="document.getElementById('avatar-input').click()" id="avatar-preview">
                        <div class="placeholder">
                            <span class="text-4xl">📷</span>
                            <span class="text-xs text-[var(--text-muted)] font-medium">أضف صورة</span>
                        </div>
                    </div>
                    <input type="file" id="avatar-input" accept="image/*" class="hidden" onchange="Profile.previewAvatar(this)">
                    <p class="text-xs text-[var(--text-muted)] mt-3">اضغط لاختيار صورة</p>
                </div>
                <div class="space-y-4 flex-1">
                    <div class="input-group">
                        <label class="input-label">الاسم الكامل</label>
                        <input type="text" id="profile-name" class="input-field" placeholder="أدخل اسمك الكامل">
                    </div>
                    <div class="input-group">
                        <label class="input-label">تاريخ الميلاد</label>
                        <input type="date" id="profile-dob" class="input-field">
                    </div>
                    <div class="input-group">
                        <label class="input-label">الولاية</label>
                        <select id="profile-wilaya" class="input-field">
                            <option value="">اختر الولاية</option>
                            <option>الجزائر العاصمة</option><option>وهران</option><option>قسنطينة</option>
                            <option>عنابة</option><option>سطيف</option><option>تلمسان</option>
                            <option>البليدة</option><option>باتنة</option><option>بجاية</option>
                            <option>سكيكدة</option><option>أخرى</option>
                        </select>
                    </div>
                    <div class="input-group">
                        <label class="input-label">رقم CCP (للسحب)</label>
                        <input type="text" id="profile-ccp" class="input-field" placeholder="XXXXXXXXXX">
                    </div>
                </div>
                <div class="mt-6 space-y-3">
                    <button class="btn btn-primary" onclick="Profile.saveSetup()">${t('save')}</button>
                    <button class="btn btn-ghost text-[var(--text-muted)]" onclick="Profile.saveSetup()">${t('skip')}</button>
                </div>
            </div>
        </div>`;
    },

    // Home
    home() {
        const user = Storage.getUser() || {};
        const name = user.name || user.phone || 'زائر';
        const balance = user.balance || 0;
        const tasks = (Storage.getMyTasks() || []).length;
        const completed = (Storage.getMyTasks() || []).filter(t => t.status === 'completed').length;
        const earnings = user.earnings || 0;

        return `
        <div id="screen-home" class="screen active">
            <div class="px-5 pt-4 pb-2 flex items-center justify-between">
                <button class="btn-icon" onclick="App.openDrawer()">☰</button>
                <div class="text-center">
                    <div class="text-xs text-[var(--text-muted)] font-medium">${t('welcome')}</div>
                    <div class="text-sm font-bold">${name}</div>
                </div>
                <div class="flex items-center gap-2">
                    <button class="btn-icon relative" onclick="App.goTo('notifications')">
                        🔔
                        ${App.hasUnreadNotifs() ? '<span class="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full"></span>' : ''}
                    </button>
                    <button class="btn-icon" onclick="App.toggleTheme()">🌙</button>
                </div>
            </div>
            <div class="px-5 mt-4">
                <div class="balance-card">
                    <div class="balance-label">${t('balance_label')}</div>
                    <div class="balance-amount">${balance.toLocaleString()} <span class="text-lg">DZD</span></div>
                    <div class="balance-actions">
                        <button class="btn-balance-secondary" onclick="App.goTo('withdraw')">${t('btn_withdraw')}</button>
                        <button class="btn-balance-primary" onclick="Wallet.showDeposit()">${t('btn_deposit')}</button>
                    </div>
                </div>
            </div>
            <div class="px-5 mt-5">
                <div class="grid-stats">
                    <div class="grid-stat">
                        <div class="grid-stat-icon">📋</div>
                        <div class="grid-stat-value">${tasks}</div>
                        <div class="grid-stat-label">${t('tasks_label')}</div>
                    </div>
                    <div class="grid-stat">
                        <div class="grid-stat-icon">✅</div>
                        <div class="grid-stat-value">${completed}</div>
                        <div class="grid-stat-label">${t('completed_label')}</div>
                    </div>
                    <div class="grid-stat">
                        <div class="grid-stat-icon">💰</div>
                        <div class="grid-stat-value">${earnings}</div>
                        <div class="grid-stat-label">${t('earnings_label')}</div>
                    </div>
                </div>
            </div>
            <div class="mt-6">
                <div class="section-header">
                    <h3>${t('available_tasks')}</h3>
                    <a href="#" onclick="App.switchTab('tasks')">${t('view_all')}</a>
                </div>
                <div class="px-5 space-y-3">
                    ${DEMO_TASKS.slice(0,3).map(task => `
                        <div class="task-card" onclick="Tasks.showDetail(${task.id})">
                            <div class="task-icon" style="background: ${task.type === 'easy' ? '#dbeafe' : task.type === 'medium' ? '#fef3c7' : task.type === 'hard' ? '#f3e8ff' : 'linear-gradient(135deg,#f59e0b,#d97706)'};">${task.icon}</div>
                            <div class="task-info">
                                <div class="task-title">${task.title}</div>
                                <div class="task-meta">عمولة: ${task.commission} DZD</div>
                            </div>
                            <div class="task-commission">${task.commission}</div>
                        </div>
                    `).join('')}
                </div>
            </div>
            <div class="h-24"></div>
        </div>`;
    },

    // Tasks List
    tasks() {
        return `
        <div id="screen-tasks" class="screen">
            <div class="page-header">
                <div>
                    <h1>${t('tasks_title')}</h1>
                    <p class="subtitle">${t('tasks_subtitle')}</p>
                </div>
                <button class="btn-icon" onclick="App.toggleTheme()">🌙</button>
            </div>
            <div class="px-5 mt-2 space-y-3 pb-24">
                ${DEMO_TASKS.map(task => `
                    <div class="task-card ${task.locked ? 'locked' : ''}" onclick="${task.locked ? '' : `Tasks.showDetail(${task.id})`}">
                        <div class="task-icon" style="background: ${task.type === 'easy' ? '#dbeafe' : task.type === 'medium' ? '#fef3c7' : task.type === 'hard' ? '#f3e8ff' : 'linear-gradient(135deg,#f59e0b,#d97706)'};">${task.icon}</div>
                        <div class="task-info">
                            <div class="flex items-center gap-2 mb-1">
                                <div class="task-title">${task.title}</div>
                                <span class="task-badge ${task.type}">${task.type === 'easy' ? 'سهل' : task.type === 'medium' ? 'متوسط' : task.type === 'hard' ? 'صعب' : 'VIP'}</span>
                            </div>
                            <p class="text-xs text-[var(--text-muted)] mb-2">${task.desc}</p>
                            <div class="flex items-center justify-between">
                                <span class="task-commission">${task.commission} DZD</span>
                                ${task.locked 
                                    ? '<span class="text-xs text-[var(--text-muted)]">🔒 مطلوب 10 مهام</span>' 
                                    : `<button class="bg-amber-500 text-white px-4 py-1.5 rounded-lg text-xs font-bold" onclick="event.stopPropagation(); Tasks.acceptTask(${task.id})">${t('task_accept')}</button>`
                                }
                            </div>
                        </div>
                    </div>
                `).join('')}
            </div>
        </div>`;
    },

    // Task Detail
    taskDetail(task) {
        const accepted = (Storage.getMyTasks() || []).find(t => t.id === task.id);
        const status = accepted ? accepted.status : 'available';

        return `
        <div id="screen-task-detail" class="screen">
            <div class="page-header">
                <button class="btn-icon" onclick="App.goBack()">→</button>
                <h1>${t('task_detail_title')}</h1>
                <div class="w-10"></div>
            </div>
            <div class="px-5 pb-6 flex-1 overflow-y-auto">
                <div class="card mb-4">
                    <div class="flex items-center gap-4 mb-4">
                        <div class="w-16 h-16 rounded-2xl flex items-center justify-center text-3xl" style="background: ${task.type === 'easy' ? '#dbeafe' : task.type === 'medium' ? '#fef3c7' : task.type === 'hard' ? '#f3e8ff' : 'linear-gradient(135deg,#f59e0b,#d97706)'};">${task.icon}</div>
                        <div>
                            <h2 class="text-xl font-black">${task.title}</h2>
                            <span class="task-badge ${task.type}">${task.type === 'easy' ? 'سهل' : task.type === 'medium' ? 'متوسط' : task.type === 'hard' ? 'صعب' : 'VIP'}</span>
                        </div>
                    </div>
                    <div class="text-3xl font-black text-amber-500 mb-2">${task.commission} DZD</div>
                    <p class="text-sm text-[var(--text-muted)] leading-relaxed">${task.desc}</p>
                </div>

                <div class="card mb-4">
                    <h3 class="font-bold mb-3">${t('task_requirements')}</h3>
                    <ul class="space-y-2">
                        ${task.requirements.map(r => `<li class="flex items-start gap-2 text-sm text-[var(--text-muted)]"><span class="text-amber-500">•</span>${r}</li>`).join('')}
                    </ul>
                </div>

                <div class="card mb-4">
                    <h3 class="font-bold mb-3">${t('task_steps')}</h3>
                    <div class="space-y-3">
                        ${task.steps.map((s, i) => `
                            <div class="flex gap-3">
                                <div class="w-8 h-8 bg-amber-100 dark:bg-amber-900/30 rounded-lg flex items-center justify-center text-amber-600 font-bold text-sm shrink-0">${i+1}</div>
                                <p class="text-sm text-[var(--text-muted)] pt-1">${s}</p>
                            </div>
                        `).join('')}
                    </div>
                </div>

                ${status === 'available' ? `
                    <button class="btn btn-primary" onclick="Tasks.acceptTask(${task.id})">${t('task_accept')}</button>
                ` : status === 'accepted' ? `
                    <div class="card mb-4">
                        <h3 class="font-bold mb-3">${t('task_proof')}</h3>
                        <div class="kyc-upload-box" onclick="document.getElementById('proof-input').click()" id="proof-preview">
                            <span class="text-3xl">📎</span>
                            <p class="text-sm text-[var(--text-muted)] mt-2">اضغط لرفع صورة أو ملف</p>
                        </div>
                        <input type="file" id="proof-input" accept="image/*" class="hidden" onchange="Tasks.previewProof(this)">
                    </div>
                    <div class="space-y-3">
                        <button class="btn btn-primary" onclick="Tasks.submitProof(${task.id})">${t('btn_submit_proof')}</button>
                        <button class="btn btn-secondary text-red-500" onclick="Tasks.cancelTask(${task.id})">${t('btn_cancel_task')}</button>
                    </div>
                ` : status === 'pending' ? `
                    <div class="card text-center py-8">
                        <div class="text-4xl mb-3">⏳</div>
                        <div class="font-bold text-lg">قيد المراجعة</div>
                        <p class="text-sm text-[var(--text-muted)] mt-2">سنقوم بمراجعة إثباتك خلال 24 ساعة</p>
                    </div>
                ` : `
                    <div class="card text-center py-8">
                        <div class="text-4xl mb-3">✅</div>
                        <div class="font-bold text-lg">تمت المهمة!</div>
                        <p class="text-sm text-[var(--text-muted)] mt-2">تم إضافة ${task.commission} DZD لرصيدك</p>
                    </div>
                `}
            </div>
        </div>`;
    },

    // Withdraw
    withdraw() {
        const user = Storage.getUser() || {};
        const balance = user.balance || 0;
        const history = Storage.getTransactions().filter(t => t.type === 'withdrawal');

        return `
        <div id="screen-withdraw" class="screen">
            <div class="page-header">
                <div>
                    <h1>${t('withdraw_title')}</h1>
                    <p class="subtitle">${t('withdraw_subtitle')}</p>
                </div>
                <button class="btn-icon" onclick="App.toggleTheme()">🌙</button>
            </div>
            <div class="px-5 mt-4">
                <div class="bg-gradient-to-br from-amber-500 to-amber-600 rounded-3xl p-6 text-white shadow-xl mb-6">
                    <div class="text-amber-100 text-sm font-medium mb-1">${t('withdrawable')}</div>
                    <div class="text-4xl font-black">${balance.toLocaleString()} <span class="text-lg">DZD</span></div>
                    <div class="mt-4 text-xs text-amber-100 bg-white/20 rounded-lg px-3 py-2 inline-block">${t('min_withdraw')}</div>
                </div>
                <h3 class="font-bold text-[var(--text)] mb-3">${t('withdraw_methods')}</h3>
                <div class="space-y-3 mb-6">
                    <div class="card flex items-center gap-4 cursor-pointer hover:border-amber-400 transition" onclick="Wallet.withdraw('ccp')">
                        <div class="w-12 h-12 bg-green-100 dark:bg-green-900/30 rounded-xl flex items-center justify-center text-2xl">🏧</div>
                        <div class="flex-1">
                            <div class="font-bold text-sm">${t('method_ccp')}</div>
                            <div class="text-xs text-[var(--text-muted)]">تحويل مباشر خلال 24 ساعة</div>
                        </div>
                        <span class="text-[var(--text-muted)]">←</span>
                    </div>
                    <div class="card flex items-center gap-4 cursor-pointer hover:border-amber-400 transition" onclick="Wallet.withdraw('wallet')">
                        <div class="w-12 h-12 bg-blue-100 dark:bg-blue-900/30 rounded-xl flex items-center justify-center text-2xl">📲</div>
                        <div class="flex-1">
                            <div class="font-bold text-sm">${t('method_wallet')}</div>
                            <div class="text-xs text-[var(--text-muted)]">D17, Mobimoney, BaridiMob</div>
                        </div>
                        <span class="text-[var(--text-muted)]">←</span>
                    </div>
                    <div class="card flex items-center gap-4 cursor-pointer hover:border-amber-400 transition" onclick="Wallet.withdraw('card')">
                        <div class="w-12 h-12 bg-purple-100 dark:bg-purple-900/30 rounded-xl flex items-center justify-center text-2xl">💳</div>
                        <div class="flex-1">
                            <div class="font-bold text-sm">${t('method_card')}</div>
                            <div class="text-xs text-[var(--text-muted)]">التحويل إلى حسابك البنكي</div>
                        </div>
                        <span class="text-[var(--text-muted)]">←</span>
                    </div>
                </div>
                <h3 class="font-bold text-[var(--text)] mb-3">${t('withdraw_history')}</h3>
                ${history.length === 0 ? `
                    <div class="card text-center py-8">
                        <div class="text-4xl mb-3">📭</div>
                        <div class="text-sm text-[var(--text-muted)]">لا يوجد سحبات بعد</div>
                    </div>
                ` : history.map(tx => `
                    <div class="tx-item">
                        <div class="tx-icon outcome">💸</div>
                        <div class="tx-info">
                            <div class="tx-title">سحب ${tx.method}</div>
                            <div class="tx-date">${new Date(tx.date).toLocaleDateString('ar-DZ')}</div>
                        </div>
                        <div class="tx-amount negative">-${tx.amount} DZD</div>
                    </div>
                `).join('')}
            </div>
        </div>`;
    },

    // Wallet / Transactions
    wallet() {
        const txs = Storage.getTransactions();
        return `
        <div id="screen-wallet" class="screen">
            <div class="page-header">
                <div>
                    <h1>${t('wallet_title')}</h1>
                </div>
                <button class="btn-icon" onclick="App.toggleTheme()">🌙</button>
            </div>
            <div class="px-5 mt-4 pb-24">
                <h3 class="font-bold text-[var(--text)] mb-3">${t('wallet_history')}</h3>
                ${txs.length === 0 ? `
                    <div class="empty-state">
                        <div class="empty-state-icon">📭</div>
                        <div class="empty-state-title">لا توجد معاملات</div>
                        <div class="empty-state-desc">ستظهر معاملاتك هنا بمجرد بدء العمل</div>
                    </div>
                ` : txs.map(tx => `
                    <div class="tx-item">
                        <div class="tx-icon ${tx.type === 'income' ? 'income' : 'outcome'}">${tx.type === 'income' ? '💰' : '💸'}</div>
                        <div class="tx-info">
                            <div class="tx-title">${tx.title}</div>
                            <div class="tx-date">${new Date(tx.date).toLocaleDateString('ar-DZ')}</div>
                        </div>
                        <div class="tx-amount ${tx.type === 'income' ? 'positive' : 'negative'}">${tx.type === 'income' ? '+' : '-'}${tx.amount} DZD</div>
                    </div>
                `).join('')}
            </div>
        </div>`;
    },

    // Profile
    profile() {
        const user = Storage.getUser() || {};
        const name = user.name || user.phone || 'زائر';
        const tasks = Storage.getMyTasks().length;
        const completed = Storage.getMyTasks().filter(t => t.status === 'completed').length;
        const earnings = user.earnings || 0;
        const level = Profile.getLevel();
        const kyc = Storage.getKyc();

        return `
        <div id="screen-profile" class="screen">
            <div class="page-header">
                <h1>${t('profile_title')}</h1>
                <button class="btn-icon" onclick="App.toggleTheme()">🌙</button>
            </div>
            <div class="px-5 mt-4 pb-24">
                <div class="card text-center py-8 mb-4">
                    <div class="w-24 h-24 bg-gradient-to-br from-amber-400 to-amber-600 rounded-full flex items-center justify-center text-4xl mx-auto mb-4 shadow-lg" id="profile-avatar-display">
                        ${user.avatar ? `<img src="${user.avatar}" class="w-full h-full object-cover rounded-full">` : '👤'}
                    </div>
                    <h3 class="text-lg font-bold">${name}</h3>
                    <div class="flex items-center justify-center gap-2 mt-2">
                        <span class="level-badge ${level.name}">${t('level_' + level.name)}</span>
                        ${kyc.status === 'verified' ? '<span class="level-badge" style="background:#d1fae5;color:#065f46">✅ محقق</span>' : '<span class="level-badge" style="background:#fef3c7;color:#92400e">⏳ غير محقق</span>'}
                    </div>
                    <div class="flex justify-center gap-6 mt-4">
                        <div class="text-center"><div class="text-xl font-black">${tasks}</div><div class="text-xs text-[var(--text-muted)]">مهام</div></div>
                        <div class="text-center"><div class="text-xl font-black">${completed}</div><div class="text-xs text-[var(--text-muted)]">مكتملة</div></div>
                        <div class="text-center"><div class="text-xl font-black text-amber-500">${earnings}</div><div class="text-xs text-[var(--text-muted)]">DZD</div></div>
                    </div>
                    <div class="mt-4 px-4">
                        <div class="flex justify-between text-xs mb-1">
                            <span>التقدم للمستوى التالي</span>
                            <span>${completed}/${level.nextThreshold}</span>
                        </div>
                        <div class="progress-bar">
                            <div class="progress-bar-fill" style="width: ${Math.min((completed / level.nextThreshold) * 100, 100)}%"></div>
                        </div>
                    </div>
                </div>
                <div class="space-y-2">
                    <div class="card flex items-center gap-4 cursor-pointer hover:bg-[var(--light)] transition" onclick="App.goTo('kyc')">
                        <div class="w-10 h-10 bg-blue-100 dark:bg-blue-900/30 rounded-xl flex items-center justify-center text-lg">🛡️</div>
                        <div class="flex-1"><div class="font-bold text-sm">التحقق من الهوية (KYC)</div><div class="text-xs text-[var(--text-muted)]">${kyc.status === 'verified' ? '✅ تم التحقق' : kyc.status === 'pending' ? '⏳ قيد المراجعة' : 'مطلوب للسحب'}</div></div>
                        <span class="text-[var(--text-muted)]">←</span>
                    </div>
                    <div class="card flex items-center gap-4 cursor-pointer hover:bg-[var(--light)] transition" onclick="App.goTo('referral')">
                        <div class="w-10 h-10 bg-green-100 dark:bg-green-900/30 rounded-xl flex items-center justify-center text-lg">🎁</div>
                        <div class="flex-1"><div class="font-bold text-sm">الإحالات</div><div class="text-xs text-[var(--text-muted)]">ادعو أصدقاءك واكسب</div></div>
                        <span class="text-[var(--text-muted)]">←</span>
                    </div>
                    <div class="card flex items-center gap-4 cursor-pointer hover:bg-[var(--light)] transition" onclick="App.goTo('leaderboard')">
                        <div class="w-10 h-10 bg-amber-100 dark:bg-amber-900/30 rounded-xl flex items-center justify-center text-lg">🏆</div>
                        <div class="flex-1"><div class="font-bold text-sm">المتصدرين</div><div class="text-xs text-[var(--text-muted)]">أفضل المسوقين</div></div>
                        <span class="text-[var(--text-muted)]">←</span>
                    </div>
                    <div class="card flex items-center gap-4 cursor-pointer hover:bg-[var(--light)] transition" onclick="App.goTo('wallet')">
                        <div class="w-10 h-10 bg-purple-100 dark:bg-purple-900/30 rounded-xl flex items-center justify-center text-lg">💳</div>
                        <div class="flex-1"><div class="font-bold text-sm">المحفظة والمعاملات</div></div>
                        <span class="text-[var(--text-muted)]">←</span>
                    </div>
                    <div class="card flex items-center gap-4 cursor-pointer hover:bg-[var(--light)] transition" onclick="App.goTo('chat')">
                        <div class="w-10 h-10 bg-pink-100 dark:bg-pink-900/30 rounded-xl flex items-center justify-center text-lg">💬</div>
                        <div class="flex-1"><div class="font-bold text-sm">الدعم الفني</div></div>
                        <span class="text-[var(--text-muted)]">←</span>
                    </div>
                    <div class="card flex items-center gap-4 cursor-pointer hover:bg-[var(--light)] transition" onclick="App.goTo('merchant')">
                        <div class="w-10 h-10 bg-indigo-100 dark:bg-indigo-900/30 rounded-xl flex items-center justify-center text-lg">🏪</div>
                        <div class="flex-1"><div class="font-bold text-sm">وضع التاجر</div><div class="text-xs text-[var(--text-muted)]">أضف منتجاتك</div></div>
                        <span class="text-[var(--text-muted)]">←</span>
                    </div>
                    <div class="card flex items-center gap-4 cursor-pointer hover:bg-red-50 dark:hover:bg-red-900/20 transition border-red-200 dark:border-red-900/30" onclick="Auth.logout()">
                        <div class="w-10 h-10 bg-red-100 dark:bg-red-900/30 rounded-xl flex items-center justify-center text-lg">🚪</div>
                        <div class="flex-1"><div class="font-bold text-red-600 text-sm">${t('logout')}</div></div>
                        <span class="text-red-400">←</span>
                    </div>
                </div>
            </div>
        </div>`;
    },

    // KYC
    kyc() {
        const kyc = Storage.getKyc();
        return `
        <div id="screen-kyc" class="screen">
            <div class="page-header">
                <button class="btn-icon" onclick="App.goBack()">→</button>
                <h1>${t('kyc_title')}</h1>
                <div class="w-10"></div>
            </div>
            <div class="px-5 pb-6 flex-1 overflow-y-auto">
                <p class="text-sm text-[var(--text-muted)] mb-4">${t('kyc_subtitle')}</p>

                ${kyc.status === 'verified' ? `
                    <div class="kyc-status verified">
                        <span class="text-2xl">✅</span>
                        <div>
                            <div class="font-bold">${t('kyc_verified')}</div>
                            <div class="text-sm">يمكنك الآن السحب بدون قيود</div>
                        </div>
                    </div>
                ` : kyc.status === 'pending' ? `
                    <div class="kyc-status pending">
                        <span class="text-2xl">⏳</span>
                        <div>
                            <div class="font-bold">${t('kyc_pending')}</div>
                            <div class="text-sm">سنقوم بالمراجعة خلال 24-48 ساعة</div>
                        </div>
                    </div>
                ` : `
                    <div class="space-y-4">
                        <div>
                            <label class="input-label">${t('kyc_id_front')}</label>
                            <div class="kyc-upload-box" onclick="document.getElementById('kyc-front').click()">
                                <span class="text-3xl">📄</span>
                                <p class="text-sm text-[var(--text-muted)] mt-2">اضغط لرفع الصورة</p>
                            </div>
                            <input type="file" id="kyc-front" accept="image/*" class="hidden" onchange="Kyc.preview(this,'front')">
                            <div id="kyc-front-preview"></div>
                        </div>
                        <div>
                            <label class="input-label">${t('kyc_id_back')}</label>
                            <div class="kyc-upload-box" onclick="document.getElementById('kyc-back').click()">
                                <span class="text-3xl">📄</span>
                                <p class="text-sm text-[var(--text-muted)] mt-2">اضغط لرفع الصورة</p>
                            </div>
                            <input type="file" id="kyc-back" accept="image/*" class="hidden" onchange="Kyc.preview(this,'back')">
                            <div id="kyc-back-preview"></div>
                        </div>
                        <div>
                            <label class="input-label">${t('kyc_selfie')}</label>
                            <div class="kyc-upload-box" onclick="document.getElementById('kyc-selfie').click()">
                                <span class="text-3xl">🤳</span>
                                <p class="text-sm text-[var(--text-muted)] mt-2">اضغط لرفع الصورة</p>
                            </div>
                            <input type="file" id="kyc-selfie" accept="image/*" class="hidden" onchange="Kyc.preview(this,'selfie')">
                            <div id="kyc-selfie-preview"></div>
                        </div>
                        <button class="btn btn-primary" onclick="Kyc.submit()">${t('btn_submit_kyc')}</button>
                    </div>
                `}
            </div>
        </div>`;
    },

    // Referral
    referral() {
        const ref = Storage.getReferral();
        const code = ref.code || Profile.generateReferralCode();
        return `
        <div id="screen-referral" class="screen">
            <div class="page-header">
                <button class="btn-icon" onclick="App.goBack()">→</button>
                <h1>${t('referral_title')}</h1>
                <div class="w-10"></div>
            </div>
            <div class="px-5 pb-6 flex-1 overflow-y-auto">
                <p class="text-sm text-[var(--text-muted)] mb-4">${t('referral_subtitle')}</p>
                <div class="referral-code-box mb-6">
                    <div class="text-sm opacity-80">${t('your_code')}</div>
                    <div class="referral-code" id="ref-code">${code}</div>
                    <div class="flex gap-3 mt-4">
                        <button class="flex-1 bg-white/20 backdrop-blur-sm rounded-xl py-2.5 text-sm font-bold" onclick="Referral.copy()">📋 ${t('copy')}</button>
                        <button class="flex-1 bg-white rounded-xl py-2.5 text-sm font-bold text-amber-600" onclick="Referral.share()">📤 ${t('share')}</button>
                    </div>
                </div>
                <div class="referral-stats">
                    <div class="referral-stat">
                        <div class="referral-stat-value">${ref.count}</div>
                        <div class="referral-stat-label">${t('referrals_count')}</div>
                    </div>
                    <div class="referral-stat">
                        <div class="referral-stat-value">${ref.earnings}</div>
                        <div class="referral-stat-label">${t('referral_earnings')}</div>
                    </div>
                    <div class="referral-stat">
                        <div class="referral-stat-value">${ref.earnings}</div>
                        <div class="referral-stat-label">${t('total_earned')}</div>
                    </div>
                </div>
            </div>
        </div>`;
    },

    // Leaderboard
    leaderboard() {
        return `
        <div id="screen-leaderboard" class="screen">
            <div class="page-header">
                <button class="btn-icon" onclick="App.goBack()">→</button>
                <h1>${t('leaderboard_title')}</h1>
                <div class="w-10"></div>
            </div>
            <div class="px-5 pb-6 flex-1 overflow-y-auto">
                <p class="text-sm text-[var(--text-muted)] mb-4">${t('leaderboard_subtitle')}</p>
                <div class="space-y-2">
                    ${DEMO_LEADERBOARD.map((user, i) => `
                        <div class="leaderboard-item">
                            <div class="leaderboard-rank ${i === 0 ? 'gold' : i === 1 ? 'silver' : i === 2 ? 'bronze' : 'normal'}">${i + 1}</div>
                            <div class="text-2xl">${user.avatar}</div>
                            <div class="leaderboard-info">
                                <div class="leaderboard-name">${user.name}</div>
                                <div class="leaderboard-amount">${user.tasks} مهمة</div>
                            </div>
                            <div class="leaderboard-earnings">${user.earnings.toLocaleString()} DZD</div>
                        </div>
                    `).join('')}
                </div>
            </div>
        </div>`;
    },

    // Notifications
    notifications() {
        const notifs = [...DEMO_NOTIFICATIONS, ...Storage.getNotifications()];
        return `
        <div id="screen-notifications" class="screen">
            <div class="page-header">
                <button class="btn-icon" onclick="App.goBack()">→</button>
                <h1>${t('notif_title')}</h1>
                <div class="w-10"></div>
            </div>
            <div class="px-5 pb-6 flex-1 overflow-y-auto">
                ${notifs.length === 0 ? `
                    <div class="empty-state">
                        <div class="empty-state-icon">🔔</div>
                        <div class="empty-state-title">${t('notif_empty')}</div>
                    </div>
                ` : notifs.map(n => `
                    <div class="notif-item ${n.read ? '' : 'unread'}" onclick="Notifications.markRead(${n.id})">
                        <div class="notif-icon ${n.type}">${n.type === 'success' ? '✅' : n.type === 'warning' ? '⚠️' : 'ℹ️'}</div>
                        <div class="notif-content">
                            <div class="notif-title">${n.title}</div>
                            <div class="notif-body">${n.body}</div>
                            <div class="notif-time">${n.time}</div>
                        </div>
                    </div>
                `).join('')}
            </div>
        </div>`;
    },

    // Chat
    chat() {
        const msgs = Storage.getChatMessages();
        return `
        <div id="screen-chat" class="screen">
            <div class="page-header">
                <button class="btn-icon" onclick="App.goBack()">→</button>
                <h1>${t('chat_title')}</h1>
                <div class="w-10"></div>
            </div>
            <div class="flex-1 overflow-y-auto px-5 py-4" id="chat-messages">
                ${msgs.map(m => `
                    <div class="chat-bubble ${m.from}">
                        ${m.text}
                        <div class="text-xs opacity-60 mt-1 text-right">${m.time}</div>
                    </div>
                `).join('')}
            </div>
            <div class="chat-input-bar">
                <input type="text" id="chat-input" placeholder="${t('chat_placeholder')}" onkeydown="if(event.key==='Enter')Chat.send()">
                <button class="btn btn-primary btn-sm" onclick="Chat.send()">إرسال</button>
            </div>
        </div>`;
    },

    // Merchant
    merchant() {
        return `
        <div id="screen-merchant" class="screen">
            <div class="page-header">
                <button class="btn-icon" onclick="App.goBack()">→</button>
                <h1>${t('merchant_title')}</h1>
                <div class="w-10"></div>
            </div>
            <div class="px-5 pb-6 flex-1 overflow-y-auto">
                <p class="text-sm text-[var(--text-muted)] mb-4">${t('merchant_subtitle')}</p>
                <div class="grid grid-cols-2 gap-3 mb-6">
                    <div class="merchant-stat-card">
                        <div class="merchant-stat-value">0</div>
                        <div class="merchant-stat-label">منتجاتي</div>
                    </div>
                    <div class="merchant-stat-card">
                        <div class="merchant-stat-value">0</div>
                        <div class="merchant-stat-label">مهام نشطة</div>
                    </div>
                    <div class="merchant-stat-card">
                        <div class="merchant-stat-value">0</div>
                        <div class="merchant-stat-label">مبيعات</div>
                    </div>
                    <div class="merchant-stat-card">
                        <div class="merchant-stat-value">0 DZD</div>
                        <div class="merchant-stat-label">إيرادات</div>
                    </div>
                </div>
                <button class="btn btn-primary mb-4">${t('merchant_add_product')}</button>
                <div class="card text-center py-12">
                    <div class="text-5xl mb-4">🏪</div>
                    <div class="font-bold text-lg mb-2">لا توجد منتجات بعد</div>
                    <p class="text-sm text-[var(--text-muted)]">أضف منتجك الأول وابدأ في التسويق</p>
                </div>
            </div>
        </div>`;
    },

    // Bottom Nav
    bottomNav() {
        return `
        <div class="bottom-nav" id="bottom-nav" style="display:none;">
            <button class="nav-item active" data-tab="home" onclick="App.switchTab('home')">
                <span class="nav-icon">🏠</span><span class="nav-label">${t('nav_home')}</span>
            </button>
            <button class="nav-item" data-tab="tasks" onclick="App.switchTab('tasks')">
                <span class="nav-icon">📋</span><span class="nav-label">${t('nav_tasks')}</span>
            </button>
            <button class="nav-item" data-tab="withdraw" onclick="App.switchTab('withdraw')">
                <span class="nav-icon">💰</span><span class="nav-label">${t('nav_withdraw')}</span>
            </button>
            <button class="nav-item" data-tab="profile" onclick="App.switchTab('profile')">
                <span class="nav-icon">👤</span><span class="nav-label">${t('nav_profile')}</span>
            </button>
        </div>`;
    },

    // Nav Drawer
    drawer() {
        const user = Storage.getUser() || {};
        const name = user.name || user.phone || 'زائر';
        return `
        <div class="drawer-overlay" id="drawer-overlay" onclick="App.closeDrawer()"></div>
        <div class="nav-drawer" id="nav-drawer">
            <div class="drawer-header">
                <div class="flex items-center justify-between">
                    <div class="text-xl font-black">Zed Earn</div>
                    <button class="btn-icon" onclick="App.closeDrawer()">✕</button>
                </div>
                <div class="drawer-user">
                    <div class="drawer-avatar" id="drawer-avatar">
                        ${user.avatar ? `<img src="${user.avatar}">` : '👤'}
                    </div>
                    <div>
                        <div class="font-bold">${name}</div>
                        <div class="text-xs text-[var(--text-muted)]">مسوق ${t('level_' + (Profile.getLevel().name))}</div>
                    </div>
                </div>
            </div>
            <div class="drawer-menu">
                <button class="drawer-item" onclick="App.closeDrawer(); App.switchTab('home')">
                    <span class="icon">🏠</span><span>${t('nav_home')}</span>
                </button>
                <button class="drawer-item" onclick="App.closeDrawer(); App.switchTab('tasks')">
                    <span class="icon">📋</span><span>${t('nav_tasks')}</span>
                </button>
                <button class="drawer-item" onclick="App.closeDrawer(); App.switchTab('withdraw')">
                    <span class="icon">💰</span><span>${t('nav_withdraw')}</span>
                </button>
                <button class="drawer-item" onclick="App.closeDrawer(); App.switchTab('profile')">
                    <span class="icon">👤</span><span>${t('nav_profile')}</span>
                </button>
                <button class="drawer-item" onclick="App.closeDrawer(); App.goTo('notifications')">
                    <span class="icon">🔔</span><span>${t('notif_title')}</span>
                </button>
                <button class="drawer-item" onclick="App.closeDrawer(); App.goTo('chat')">
                    <span class="icon">💬</span><span>${t('chat_title')}</span>
                </button>
            </div>
            <div class="px-4 pb-6">
                <button class="drawer-item" onclick="App.toggleTheme(); App.closeDrawer()">
                    <span class="icon">🌙</span><span>الوضع الليلي / النهاري</span>
                </button>
                <button class="drawer-item text-red-600" onclick="Auth.logout()">
                    <span class="icon">🚪</span><span>${t('logout')}</span>
                </button>
            </div>
        </div>`;
    },
};
