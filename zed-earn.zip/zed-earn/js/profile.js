// ===== ZED EARN - PROFILE =====

const Profile = {
    previewAvatar(input) {
        if (input.files && input.files[0]) {
            const reader = new FileReader();
            reader.onload = function(e) {
                const preview = document.getElementById('avatar-preview');
                if (preview) {
                    preview.innerHTML = '<img src="' + e.target.result + '" style="width:100%;height:100%;object-fit:cover;border-radius:50%;">';
                }
            };
            reader.readAsDataURL(input.files[0]);
        }
    },

    saveSetup() {
        const name = document.getElementById('profile-name')?.value || '';
        const dob = document.getElementById('profile-dob')?.value || '';
        const wilaya = document.getElementById('profile-wilaya')?.value || '';
        const ccp = document.getElementById('profile-ccp')?.value || '';

        const user = Storage.getUser() || {};
        if (name) user.name = name;
        if (dob) user.dob = dob;
        if (wilaya) user.wilaya = wilaya;
        if (ccp) user.ccp = ccp;

        const avatarPreview = document.getElementById('avatar-preview');
        const img = avatarPreview?.querySelector('img');
        if (img) user.avatar = img.src;

        Storage.setUser(user);
        App.showToast('تم حفظ الملف الشخصي!');
        App.goTo('home');
    },

    getLevel() {
        const completed = (Storage.getMyTasks() || []).filter(t => t.status === 'completed').length;
        if (completed >= 100) return { name: 'vip', nextThreshold: 200 };
        if (completed >= 50) return { name: 'pro', nextThreshold: 100 };
        if (completed >= 10) return { name: 'active', nextThreshold: 50 };
        return { name: 'beginner', nextThreshold: 10 };
    },

    generateReferralCode() {
        const user = Storage.getUser() || {};
        const name = (user.name || user.phone || 'USER').toString().substring(0, 4).toUpperCase();
        const num = Math.floor(1000 + Math.random() * 9000);
        return `ZED-${name}-${num}`;
    }
};
