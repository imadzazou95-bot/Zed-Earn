// ===== ZED EARN - MAIN APP =====

window.APP_LANG = Storage.getLang();

const App = {
    currentScreen: 'splash',
    screenHistory: [],

    init() {
        this.applyTheme(Storage.getTheme());
        this.applyLang(Storage.getLang());
        this.renderAll();

        const user = Storage.getUser();
        if (user) {
            setTimeout(() => this.goTo('home'), 2500);
        } else {
            setTimeout(() => this.goTo('onboarding'), 2500);
        }
    },

    renderAll() {
        const app = document.getElementById('app');
        app.innerHTML = 
            Screens.splash() +
            Screens.onboarding() +
            Screens.register() +
            Screens.login() +
            Screens.otp() +
            Screens.scrollspy() +
            Screens.profileSetup() +
            Screens.home() +
            Screens.tasks() +
            Screens.withdraw() +
            Screens.wallet() +
            Screens.profile() +
            Screens.kyc() +
            Screens.referral() +
            Screens.leaderboard() +
            Screens.notifications() +
            Screens.chat() +
            Screens.merchant() +
            Screens.bottomNav() +
            Screens.drawer();
    },

    goTo(screenId) {
        if (this.currentScreen) {
            this.screenHistory.push(this.currentScreen);
        }
        this.currentScreen = screenId;

        document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
        const target = document.getElementById('screen-' + screenId);
        if (target) target.classList.add('active');

        const appScreens = ['home','tasks','withdraw','profile','wallet','notifications','chat','leaderboard','referral','kyc','merchant'];
        const bottomNav = document.getElementById('bottom-nav');
        if (bottomNav) {
            bottomNav.style.display = appScreens.includes(screenId) ? 'flex' : 'none';
        }

        if (appScreens.includes(screenId)) {
            document.querySelectorAll('.nav-item').forEach(item => {
                item.classList.toggle('active', item.dataset.tab === screenId);
            });
        }

        window.scrollTo(0, 0);
    },

    goBack() {
        const prev = this.screenHistory.pop();
        if (prev) {
            this.currentScreen = prev;
            document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
            const target = document.getElementById('screen-' + prev);
            if (target) target.classList.add('active');
        }
    },

    switchTab(tab) {
        // Re-render dynamic screens
        if (tab === 'home') {
            const app = document.getElementById('app');
            const old = document.getElementById('screen-home');
            if (old) old.outerHTML = Screens.home();
        }
        if (tab === 'profile') {
            const old = document.getElementById('screen-profile');
            if (old) old.outerHTML = Screens.profile();
        }
        if (tab === 'withdraw') {
            const old = document.getElementById('screen-withdraw');
            if (old) old.outerHTML = Screens.withdraw();
        }
        this.goTo(tab);
    },

    nextOnboarding(step) {
        document.querySelectorAll('.onboarding-slide').forEach(s => s.classList.remove('active'));
        document.getElementById('ob-slide-' + step).classList.add('active');

        for (let i = 1; i <= 3; i++) {
            const circle = document.getElementById('ob-step-' + i);
            const line = document.getElementById('ob-line-' + i);
            if (i < step) {
                circle.className = 'step-circle done';
                circle.innerHTML = '✓';
                if (line) line.className = 'step-line done';
            } else if (i === step) {
                circle.className = 'step-circle active';
                circle.innerHTML = i;
            } else {
                circle.className = 'step-circle pending';
                circle.innerHTML = i;
                if (line) line.className = 'step-line pending';
            }
        }
    },

    scrollToSection(id, el) {
        document.getElementById(id).scrollIntoView({ behavior: 'smooth' });
        document.querySelectorAll('.scrollspy-link').forEach(l => l.classList.remove('active'));
        el.classList.add('active');
    },

    openDrawer() {
        document.getElementById('nav-drawer').classList.add('open');
        document.getElementById('drawer-overlay').classList.add('open');
    },

    closeDrawer() {
        document.getElementById('nav-drawer').classList.remove('open');
        document.getElementById('drawer-overlay').classList.remove('open');
    },

    toggleTheme() {
        const isDark = document.documentElement.classList.toggle('dark');
        Storage.setTheme(isDark ? 'dark' : 'light');
        document.querySelectorAll('.theme-btn').forEach(btn => {
            btn.innerHTML = isDark ? '☀️' : '🌙';
        });
    },

    applyTheme(theme) {
        if (theme === 'dark') {
            document.documentElement.classList.add('dark');
        }
    },

    applyLang(lang) {
        window.APP_LANG = lang;
        document.documentElement.lang = lang;
        document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
        Storage.setLang(lang);
    },

    hasUnreadNotifs() {
        const notifs = [...DEMO_NOTIFICATIONS, ...Storage.getNotifications()];
        return notifs.some(n => !n.read);
    },

    showToast(message, type = 'success') {
        const toast = document.createElement('div');
        toast.className = `fixed top-4 left-1/2 -translate-x-1/2 px-6 py-3 rounded-2xl text-white font-bold text-sm z-[100] shadow-xl ${type === 'success' ? 'bg-green-500' : type === 'error' ? 'bg-red-500' : 'bg-amber-500'}`;
        toast.textContent = message;
        document.body.appendChild(toast);
        setTimeout(() => toast.remove(), 3000);
    }
};

// Initialize
document.addEventListener('DOMContentLoaded', () => App.init());
